import { useEffect, useState } from 'react'
import Navbar from "./components/Navbar";
import GalleryPage from "./pages/GalleryPage";
import ManagePage from "./pages/ManagePage";

import { getProducts, creatProduct, updateProduct, deleteProduct } from "./api";

function App() {
  const [products, setProducts] = useState([]);
  const [view, setView] = useState("gallery");
  const [editingProduct, setEditingProduct] = useState(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    getProducts()
      .then((data) => setProducts(data))
      .catch(() => setError("Could not load products. Refresh in 1 minute."))
      .finally(() => setLoading(false));
  }, []);

  const saveProduct = async (data) => {
    if (editingProduct) {
      const updated = await updateProduct(editingProduct._id, data);
      setProducts((prev) => 
        prev.map((p) => p._id === updated._id ? updated : p)
      );
      setEditingProduct(null);
    } else {
      const created = await creatProduct(data);
      setProducts((prev) => [created, ...prev]);
    }
  };

  const removeProduct = async (id) => {
    if (!confirm("Delete this product?")) return;
    try {
      await deleteProduct(id);
      setProducts((prev) => prev.filter((p) => p._id !== id));
      if(editingProduct?._id === id) setEditingProduct(null);
    } catch (err) {
      console.error(err);
      setError("Could not delete the product.");
    }
  };

  const startEdit = (product) => {
    setEditingProduct(product);
    window.scrollTo({top: 0, behavior: "smooth"});
  };

  return(
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <Navbar view={view} onChangeView={setView}/>

      {error && (
        <div className="mx-auto mt-6 max-w-6xl px-6">
          <p className="rounded-xl bg-red-50 p-4 text-red-600">{error}</p>
        </div>
      )}

      {view === "gallery" ? (
        <GalleryPage products={products} loading={loading}/>
      ) : (
        <ManagePage
          products={products}
          editingProduct={editingProduct}
          onEdit={startEdit}
          onSave={saveProduct}
          onCancel={()=>setEditingProduct(null)}
          onDelete={removeProduct}
        />
      )}

      <footer className="py-10 text-center text-sm text-slate-400">
        Ma. Alexis T. Burgonio • INF233
      </footer>
    </div>
  )
}

export default App
